# PlayerParticleUI
remade Player Particle plugin made https://github.com/J0k3rrWild, Made Player Particle UI.

# Commands
|**Command**|**Description**|
|-----------|---------------|
|`/pui`|Open PlayerParticle Menu|

# Permission

 ```particle.portal```
 ```particle.flame```
 ```particle.explode```
 ```particle.entityflame```
 ```particle.water```
 ```particle.waterdrip```
 ```particle.lava```
 ```particle.lavadrip```
 ```particle.heart```
 ```particle.angryvillager```
 ```particle.happyvillager```
 ```particle.critical```
 ```particle.enchanttable```
 ```particle.ink```
 ```particle.spore```
 ```particle.smoke```
 ```particle.snowball```
 ```particle.redstone```
 ```particle.floatingtxt``` - New!! It is spawn rainbow floating text particle with your nick
